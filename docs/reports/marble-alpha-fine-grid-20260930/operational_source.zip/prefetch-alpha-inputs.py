"""Prepare late-grid inputs using the exact frozen exporter command."""

import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path

from scripts.marble.run_multirat_projection import ROOT, execute
from utils.utils_marble import read_json, save_json, sha256

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
output = Path("D:/MARBLE-experiments/KAIR/alpha-fine-grid-20260930")
frozen = read_json(output / "frozen_protocol.json")
work = [j for j in frozen["jobs"] if j["alpha"] == 0.05]
assert len(work) == 8 and not any(j["reused"] for j in work)
assert not any(Path(j["folder"]).exists() for j in work)
repository = ROOT.parent / "MARBLE"
receipt = {
    "created_utc": datetime.now(UTC).isoformat(),
    "source_sha256": sha256(Path(__file__)),
    "frozen_protocol_sha256": sha256(output / "frozen_protocol.json"),
    "jobs": work,
    "cpu_workers": 2,
    "training_changed": False,
    "exporter_changed": False,
    "status": "running",
}
save_json(output / "preparation_scheduling.json", receipt)


def prepare(job):
    folder = Path(job["folder"])
    folder.mkdir(parents=True)
    execute(
        [
            repository / "reproduction/.venv/Scripts/python.exe",
            "-m",
            "scripts.marble.multirat_reference",
            "--marble-repo",
            repository,
            "--data",
            ROOT.parent / "MARBLE-reproduction/paper/data/rat",
            "--output",
            folder / "input",
            "--animal",
            job["animal"],
            "--protocol",
            job["protocol"],
            "--alpha",
            job["alpha"],
        ],
        folder / "prepare.log",
    )
    assert (folder / "input/prepared.json").is_file()


with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(prepare, work))
receipt["status"] = "completed"
receipt["completed_utc"] = datetime.now(UTC).isoformat()
save_json(output / "preparation_scheduling.json", receipt)
