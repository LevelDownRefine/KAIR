$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath '.').ProviderPath
$coarseRoot = 'D:\MARBLE-experiments\KAIR\alpha-grid-20260930'
$fineRoot = 'D:\MARBLE-experiments\KAIR\alpha-fine-grid-20260930'
$discoveryRoot = Join-Path $repoRoot 'results\dynamics-projection-20260929'
$allowedRoots = @('D:\MARBLE-experiments\KAIR', $discoveryRoot)
$coarse = Get-Content -LiteralPath "$coarseRoot\frozen_protocol.json" -Raw -Encoding utf8 | ConvertFrom-Json
$fine = Get-Content -LiteralPath "$fineRoot\frozen_protocol.json" -Raw -Encoding utf8 | ConvertFrom-Json
$activeFolders = @($fine.jobs | ForEach-Object { [IO.Path]::GetFullPath($_.folder) })
$selected = @($coarse.jobs | Where-Object { $_.alpha -in @(0.1, 0.3, 1.0) })
if ($selected.Count -ne 24) { throw 'Unexpected coarse selection' }
$folders = @($selected | ForEach-Object { $_.folder })
$folders += @($selected | Where-Object { $_.protocol -eq 'consistency' } | ForEach-Object { Join-Path $coarseRoot "numerics\$($_.animal)\$($_.condition)" })
$folders += Join-Path $discoveryRoot 'joint-10'
$folders = @($folders | Sort-Object -Unique)
$files = @()
$kept = @()
foreach ($folder in $folders) {
    $absolute = (Resolve-Path -LiteralPath $folder).ProviderPath
    $rootMatches = @($allowedRoots | Where-Object { $absolute.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) })
    if ($rootMatches.Count -ne 1) { throw "Outside named roots: $absolute" }
    if ($absolute -in $activeFolders) { throw "Active folder: $absolute" }
    $ancestor = Get-Item -LiteralPath $absolute
    while ($null -ne $ancestor) {
        if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $($ancestor.FullName)" }
        $ancestor = $ancestor.Parent
    }
    foreach ($item in Get-ChildItem -LiteralPath $absolute -Recurse -File) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse file: $($item.FullName)" }
        if (-not $item.FullName.StartsWith($absolute + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Escaped target' }
        if ($item.Name -match '\.bak($|\.)') { throw 'Backup found; stop' }
        $entry = [ordered]@{path=$item.FullName; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
        if ($item.Extension -in @('.pt', '.pth', '.gz')) { $files += $entry } else { $kept += $entry }
    }
}
$receiptPath = Join-Path $repoRoot 'docs\reports\marble-alpha-cleanup-20260930.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup receipt already exists' }
$receipt = [ordered]@{
    status='planned'; requested_by='user: delete poorly performing results to save space';
    excluded_alphas=@(0.1,0.3,1,10); active_alphas=$fine.alphas;
    coarse_manifest_sha256=(Get-FileHash -LiteralPath "$coarseRoot\frozen_protocol.json").Hash.ToLowerInvariant();
    fine_manifest_sha256=(Get-FileHash -LiteralPath "$fineRoot\frozen_protocol.json").Hash.ToLowerInvariant();
    files=$files; retained_files=$kept; total_bytes=0L;
    scope='Delete only derived tensor/checkpoint/compressed sampling artifacts; retain metrics, logs, manifests, audits and all active-grid dependencies.'
}
foreach ($entry in $files) { $receipt.total_bytes += [long]$entry['bytes'] }
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
foreach ($entry in $files) {
    $file = Get-Item -LiteralPath $entry.path
    if ($file.Length -ne $entry.bytes) { throw "Changed file: $($entry.path)" }
    Remove-Item -LiteralPath $entry.path -Force
}
foreach ($entry in $files) { if (Test-Path -LiteralPath $entry.path) { throw "Not deleted: $($entry.path)" } }
foreach ($entry in $kept) {
    if ((Get-FileHash -LiteralPath $entry.path).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Retained file changed: $($entry.path)" }
}
$receipt.status = 'completed'
$receipt.completed_utc = [DateTime]::UtcNow.ToString('o')
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
[pscustomobject]@{deleted_files=$files.Count; retained_files=$kept.Count; freed_gib=[Math]::Round($receipt.total_bytes/1GB,3); receipt=$receiptPath}
